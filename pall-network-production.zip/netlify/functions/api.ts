import express from 'express';
import serverless from 'serverless-http';
import { registerRoutes } from '../../server/routes';

const app = express();

// Create the serverless function
const handler = async (event: any, context: any) => {
  // Register routes once
  if (!app._router) {
    await registerRoutes(app);
  }
  
  // Use serverless-http to handle the request
  const serverlessHandler = serverless(app);
  return serverlessHandler(event, context);
};

export { handler };