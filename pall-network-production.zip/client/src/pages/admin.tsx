import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useEffect } from "react";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import type { User } from "@shared/schema";

interface AdminStats {
  totalUsers: number;
  totalMinedCoins: string;
  dailyActiveMiners: number;
  topMiners: Array<{ user: User; totalMined: string }>;
}
import TopNav from "@/components/ui/top-nav";
import BottomNav from "@/components/ui/bottom-nav";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield, Users, Coins, Activity, RefreshCw, TrendingUp } from "lucide-react";

export default function AdminPage() {
  const { user, isLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !user) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [user, isLoading, toast]);

  // Redirect if not admin
  useEffect(() => {
    if (user && !user.isAdmin) {
      toast({
        title: "Access Denied",
        description: "Admin privileges required",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/";
      }, 1000);
    }
  }, [user, toast]);

  // Fetch admin stats
  const { data: stats, isLoading: statsLoading } = useQuery<AdminStats>({
    queryKey: ["/api/admin/stats"],
    retry: false,
    enabled: !!user?.isAdmin,
  });

  // Fetch all users
  const { data: allUsers = [], isLoading: usersLoading } = useQuery<User[]>({
    queryKey: ["/api/admin/users"],
    retry: false,
    enabled: !!user?.isAdmin,
  });

  // Reset timer mutation
  const resetTimerMutation = useMutation({
    mutationFn: async (userId: string) => {
      const response = await apiRequest("POST", `/api/admin/reset-timer/${userId}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: "Timer Reset",
        description: "User mining timer has been reset successfully",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Reset Failed",
        description: error.message || "Failed to reset timer",
        variant: "destructive",
      });
    },
  });

  const formatDate = (timestamp: string) => {
    return new Date(timestamp).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const canUserMine = (lastMinedAt: string | null) => {
    if (!lastMinedAt) return true;
    const now = new Date();
    const lastMined = new Date(lastMinedAt);
    const timeDiff = now.getTime() - lastMined.getTime();
    const twentyFourHours = 24 * 60 * 60 * 1000;
    return timeDiff >= twentyFourHours;
  };

  if (isLoading || !user) {
    return (
      <div className="min-h-screen bg-[hsl(var(--crypto-primary))] flex items-center justify-center">
        <div className="animate-spin w-12 h-12 border-4 border-gray-600 border-t-green-400 rounded-full"></div>
      </div>
    );
  }

  if (!user.isAdmin) {
    return (
      <div className="min-h-screen bg-[hsl(var(--crypto-primary))] flex items-center justify-center">
        <Card className="crypto-card border-0 max-w-md mx-4">
          <CardContent className="p-6 text-center">
            <Shield className="h-12 w-12 text-red-400 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-white mb-2">Access Denied</h2>
            <p className="text-gray-400">This page requires admin privileges.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[hsl(var(--crypto-primary))] text-white pb-20">
      <TopNav />
      
      <main className="max-w-lg mx-auto px-4 py-6 space-y-6">
        {/* Admin Header */}
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-bold text-white flex items-center justify-center space-x-2">
            <Shield className="h-6 w-6" />
            <span>Admin Panel</span>
          </h2>
          <p className="text-gray-400">Manage Pall Network operations</p>
        </div>

        {/* Stats Overview */}
        {statsLoading ? (
          <div className="text-center">
            <div className="animate-spin w-8 h-8 border-4 border-gray-600 border-t-green-400 rounded-full mx-auto"></div>
          </div>
        ) : stats && (
          <div className="grid grid-cols-2 gap-4">
            <Card className="crypto-card border-0">
              <CardContent className="p-4 text-center">
                <Users className="text-blue-400 text-2xl mb-2 mx-auto" />
                <p className="text-gray-400 text-sm">Total Users</p>
                <p className="text-2xl font-bold text-white" data-testid="text-total-users">
                  {stats.totalUsers}
                </p>
              </CardContent>
            </Card>
            
            <Card className="crypto-card border-0">
              <CardContent className="p-4 text-center">
                <Coins className="text-green-400 text-2xl mb-2 mx-auto" />
                <p className="text-gray-400 text-sm">Total Mined</p>
                <p className="text-2xl font-bold text-white" data-testid="text-total-mined-coins">
                  {parseFloat(stats.totalMinedCoins).toFixed(1)}
                </p>
                <p className="text-green-400 text-xs">PLC</p>
              </CardContent>
            </Card>
            
            <Card className="crypto-card border-0">
              <CardContent className="p-4 text-center">
                <Activity className="text-yellow-400 text-2xl mb-2 mx-auto" />
                <p className="text-gray-400 text-sm">Daily Active</p>
                <p className="text-2xl font-bold text-white" data-testid="text-daily-active">
                  {stats.dailyActiveMiners}
                </p>
              </CardContent>
            </Card>
            
            <Card className="crypto-card border-0">
              <CardContent className="p-4 text-center">
                <TrendingUp className="text-purple-400 text-2xl mb-2 mx-auto" />
                <p className="text-gray-400 text-sm">Top Miners</p>
                <p className="text-2xl font-bold text-white" data-testid="text-top-miners">
                  {stats.topMiners.length}
                </p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Top Miners */}
        {stats?.topMiners && stats.topMiners.length > 0 && (
          <Card className="crypto-card border-0">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <TrendingUp className="h-5 w-5 text-green-400" />
                <span>Top Miners</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y divide-gray-700">
                {stats.topMiners.slice(0, 5).map((miner, index: number) => (
                  <div key={miner.user.id} className="p-4 flex items-center justify-between" data-testid={`top-miner-${index}`}>
                    <div className="flex items-center space-x-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                        index === 0 ? 'bg-yellow-500' : index === 1 ? 'bg-gray-400' : index === 2 ? 'bg-orange-600' : 'bg-gray-600'
                      }`}>
                        {index + 1}
                      </div>
                      <div>
                        <p className="text-white font-medium">
                          {miner.user.username || miner.user.firstName || 'Anonymous'}
                        </p>
                        <p className="text-gray-400 text-sm">
                          Level {miner.user.miningLevel || 1}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-green-400 font-semibold">{parseFloat(miner.totalMined).toFixed(1)} PLC</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* User Management */}
        <Card className="crypto-card border-0">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Users className="h-5 w-5 text-blue-400" />
              <span>User Management</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {usersLoading ? (
              <div className="p-6 text-center">
                <div className="animate-spin w-8 h-8 border-4 border-gray-600 border-t-green-400 rounded-full mx-auto"></div>
                <p className="text-gray-400 mt-2">Loading users...</p>
              </div>
            ) : (
              <div className="divide-y divide-gray-700 max-h-96 overflow-y-auto">
                {allUsers.slice(0, 20).map((adminUser) => (
                  <div key={adminUser.id} className="p-4" data-testid={`admin-user-${adminUser.id}`}>
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <p className="text-white font-medium">
                          {adminUser.username || adminUser.firstName || 'Anonymous'}
                        </p>
                        <p className="text-gray-400 text-sm">{adminUser.email}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-green-400 font-semibold">{parseFloat(adminUser.totalMined || '0').toFixed(1)} PLC</p>
                        <p className="text-gray-400 text-xs">Total Mined</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex space-x-4">
                        <span className="text-gray-400">
                          Level: <span className="text-white">{adminUser.miningLevel || 1}</span>
                        </span>
                        <span className="text-gray-400">
                          Streak: <span className="text-white">{adminUser.miningStreak || 0}</span>
                        </span>
                      </div>
                      
                      {adminUser.lastMinedAt && (
                        <div className="flex items-center space-x-2">
                          <span className={`text-xs px-2 py-1 rounded ${
                            canUserMine(adminUser.lastMinedAt.toString()) ? 'bg-green-600 text-white' : 'bg-red-600 text-white'
                          }`}>
                            {canUserMine(adminUser.lastMinedAt.toString()) ? 'Can Mine' : 'Cooldown'}
                          </span>
                          
                          {!canUserMine(adminUser.lastMinedAt.toString()) && (
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-7 px-2 text-xs border-green-600 text-green-400 hover:bg-green-600 hover:text-white"
                              onClick={() => resetTimerMutation.mutate(adminUser.id)}
                              disabled={resetTimerMutation.isPending}
                              data-testid={`button-reset-timer-${adminUser.id}`}
                            >
                              <RefreshCw className="h-3 w-3 mr-1" />
                              Reset
                            </Button>
                          )}
                        </div>
                      )}
                    </div>
                    
                    {adminUser.lastMinedAt && (
                      <p className="text-gray-500 text-xs mt-1">
                        Last mined: {formatDate(adminUser.lastMinedAt.toString())}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>

      <BottomNav currentPage="admin" />
    </div>
  );
}
