import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Coins, Users, Shield, Zap } from "lucide-react";
import pallLogo from "@assets/channels4_profile_1754472714781.jpg";
import { useState } from "react";

export default function Landing() {
  const [showComingSoon, setShowComingSoon] = useState(false);

  const handleSecureWalletClick = () => {
    setShowComingSoon(true);
    setTimeout(() => setShowComingSoon(false), 3000); // Hide after 3 seconds
  };

  return (
    <div className="min-h-screen crypto-grid-bg text-white relative">
      {/* Blockchain Nodes */}
      <div className="blockchain-nodes">
        <div className="blockchain-node" style={{ top: '10%', left: '15%' }}></div>
        <div className="blockchain-node" style={{ top: '25%', right: '20%' }}></div>
        <div className="blockchain-node" style={{ top: '60%', left: '10%' }}></div>
        <div className="blockchain-node" style={{ top: '80%', right: '15%' }}></div>
        <div className="blockchain-node" style={{ top: '40%', left: '50%' }}></div>
        <div className="blockchain-node" style={{ top: '70%', right: '40%' }}></div>
      </div>
      
      {/* Content Container */}
      <div className="relative z-10">
      {/* Header */}
      <header className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg overflow-hidden bg-white/10">
              <img 
                src={pallLogo} 
                alt="Pall Network Logo" 
                className="w-full h-full object-cover"
              />
            </div>
            <h1 className="text-2xl font-bold text-white">Pall Network</h1>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main className="container mx-auto px-4 py-12 text-center">
        <div className="max-w-4xl mx-auto space-y-8">
          <div className="space-y-4">
            <h2 className="text-4xl md:text-6xl font-bold text-white">
              Mine Pall Coins Daily
            </h2>
            <p className="text-xl text-cyan-100 max-w-2xl mx-auto">
              Join the Pall Network and earn PLC tokens by mining once every 24 hours. 
              Build your crypto portfolio with our innovative tap-to-mine system.
            </p>
          </div>

          {/* CTA */}
          <div className="space-y-4">
            <Button 
              size="lg" 
              className="glow-button bg-gradient-to-r from-cyan-500 to-green-500 hover:from-cyan-600 hover:to-green-600 text-white text-lg px-8 py-3 transform hover:scale-105 transition-all duration-300 shadow-lg shadow-cyan-500/25"
              onClick={() => window.location.href = '/api/login'}
              data-testid="button-login"
            >
              Start Mining Now
            </Button>
            <p className="text-cyan-200">Get started in seconds with secure authentication</p>
          </div>

          {/* Features */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mt-16">
            <Card className="glass-card border-cyan-500/20">
              <CardContent className="p-6 text-center">
                <Coins className="h-12 w-12 text-cyan-400 mx-auto mb-4" />
                <h3 className="font-semibold mb-2 text-white">Daily Mining</h3>
                <p className="text-sm text-cyan-100">
                  Mine 1 PLC token every 24 hours with our tap-to-mine system
                </p>
              </CardContent>
            </Card>

            <Card className="glass-card border-green-500/20">
              <CardContent className="p-6 text-center">
                <Users className="h-12 w-12 text-green-400 mx-auto mb-4" />
                <h3 className="font-semibold mb-2 text-white">Referral Rewards</h3>
                <p className="text-sm text-green-100">
                  Earn 0.1 PLC bonus for each friend you refer to the network
                </p>
              </CardContent>
            </Card>

            <Card 
              className="glass-card border-blue-500/20 cursor-pointer hover:border-blue-400/40 transition-colors relative"
              onClick={handleSecureWalletClick}
            >
              <CardContent className="p-6 text-center">
                <Shield className="h-12 w-12 text-blue-400 mx-auto mb-4" />
                <h3 className="font-semibold mb-2 text-white">Secure Wallet</h3>
                <p className="text-sm text-blue-100">
                  Your PLC tokens are safely stored in your personal wallet
                </p>
                {showComingSoon && (
                  <div className="absolute inset-0 bg-blue-800/90 flex items-center justify-center rounded-lg backdrop-blur-sm">
                    <p className="text-white font-bold text-lg drop-shadow-lg">Coming Soon!</p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="glass-card border-purple-500/20">
              <CardContent className="p-6 text-center">
                <Zap className="h-12 w-12 text-purple-400 mx-auto mb-4" />
                <h3 className="font-semibold mb-2 text-white">Future Ready</h3>
                <p className="text-sm text-purple-100">
                  Built for blockchain integration and token utility expansion
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Stats */}
          <div className="mt-16 pt-8 border-t border-cyan-500/30">
            <div className="grid grid-cols-3 gap-8 text-center">
              <div>
                <div className="text-3xl font-bold text-cyan-400">24h</div>
                <div className="text-cyan-200">Mining Cycle</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-green-400">1 PLC</div>
                <div className="text-green-200">Per Mining</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-blue-400">0.1 PLC</div>
                <div className="text-blue-200">Referral Bonus</div>
              </div>
            </div>
          </div>
        </div>
      </main>
      </div>
    </div>
  );
}
