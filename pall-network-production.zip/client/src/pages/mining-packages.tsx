import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Crown, Zap, Clock, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { MiningPackage, UserMiningPackage } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

interface CurrentPackageResponse {
  package: MiningPackage;
  userPackage: UserMiningPackage;
}

export default function MiningPackages() {
  const { toast } = useToast();

  const { data: packages = [], isLoading: packagesLoading } = useQuery<MiningPackage[]>({
    queryKey: ["/api/mining/packages"],
  });

  const { data: currentPackage, isLoading: currentPackageLoading } = useQuery<CurrentPackageResponse | null>({
    queryKey: ["/api/mining/current-package"],
  });

  const upgradeMutation = useMutation({
    mutationFn: async (packageId: string) => {
      const response = await apiRequest("POST", "/api/mining/upgrade-package", { packageId });
      return await response.json();
    },
    onSuccess: (result) => {
      toast({
        title: "Package Upgraded!",
        description: result.message,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/mining/current-package"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
    },
    onError: (error: any) => {
      toast({
        title: "Upgrade Failed",
        description: error.message || "Failed to upgrade package",
        variant: "destructive",
      });
    },
  });

  const getPackageIcon = (name: string) => {
    if (name.includes("Gold")) return <Crown className="h-8 w-8 text-yellow-400" />;
    if (name.includes("Silver")) return <Zap className="h-8 w-8 text-gray-300" />;
    if (name.includes("Bronze")) return <Zap className="h-8 w-8 text-amber-600" />;
    return <Zap className="h-8 w-8 text-cyan-400" />;
  };

  const getPackageColor = (name: string) => {
    if (name.includes("Gold")) return "border-yellow-500/30 bg-yellow-500/5";
    if (name.includes("Silver")) return "border-gray-300/30 bg-gray-300/5";
    if (name.includes("Bronze")) return "border-amber-600/30 bg-amber-600/5";
    return "border-cyan-500/30 bg-cyan-500/5";
  };

  const isCurrentPackage = (pkg: MiningPackage) => {
    return currentPackage?.package.id === pkg.id;
  };

  const formatDuration = (days: number) => {
    if (days === 0) return "Forever";
    if (days === 30) return "1 Month";
    if (days === 180) return "6 Months";
    if (days === 365) return "1 Year";
    return `${days} Days`;
  };

  const getTimeRemaining = () => {
    if (!currentPackage?.userPackage.expiresAt) return null;
    const expiresAt = new Date(currentPackage.userPackage.expiresAt);
    const now = new Date();
    if (expiresAt <= now) return "Expired";
    return formatDistanceToNow(expiresAt, { addSuffix: true });
  };

  if (packagesLoading || currentPackageLoading) {
    return (
      <div className="min-h-screen crypto-grid-bg text-white p-6">
        <div className="container mx-auto">
          <div className="text-center">Loading mining packages...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen crypto-grid-bg text-white p-6">
      <div className="container mx-auto max-w-6xl">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4 text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-green-400">
            Mining Speed Offers
          </h1>
          <p className="text-xl text-cyan-100 max-w-2xl mx-auto">
            Upgrade your mining package to earn more PLC tokens per tap. Choose the package that fits your mining goals.
          </p>
        </div>

        {/* Current Package Status */}
        {currentPackage && (
          <div className="mb-8">
            <Card className="glass-card border-green-500/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <CheckCircle className="h-5 w-5 text-green-400" />
                  Current Active Package
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    {getPackageIcon(currentPackage.package.name)}
                    <div>
                      <h3 className="text-xl font-semibold text-white">{currentPackage.package.name}</h3>
                      <p className="text-green-400">{currentPackage.package.multiplier}x Mining Speed</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-white">
                      {currentPackage.userPackage.expiresAt ? (
                        <>
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4" />
                            <span>{getTimeRemaining()}</span>
                          </div>
                        </>
                      ) : (
                        <Badge variant="default" className="bg-green-500">Active Forever</Badge>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Mining Packages Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {packages.map((pkg) => (
            <Card
              key={pkg.id}
              className={`glass-card ${getPackageColor(pkg.name)} relative overflow-hidden`}
              data-testid={`card-package-${pkg.id}`}
            >
              {isCurrentPackage(pkg) && (
                <div className="absolute top-4 right-4">
                  <Badge variant="default" className="bg-green-500" data-testid={`badge-active-${pkg.id}`}>
                    Active
                  </Badge>
                </div>
              )}
              
              <CardHeader className="text-center">
                <div className="flex justify-center mb-4">
                  {getPackageIcon(pkg.name)}
                </div>
                <CardTitle className="text-white" data-testid={`text-package-name-${pkg.id}`}>
                  {pkg.name}
                </CardTitle>
                <CardDescription className="text-cyan-100">
                  {pkg.description}
                </CardDescription>
              </CardHeader>

              <CardContent className="text-center space-y-4">
                <div>
                  <div className="text-3xl font-bold text-white" data-testid={`text-multiplier-${pkg.id}`}>
                    {pkg.multiplier}x
                  </div>
                  <div className="text-cyan-200">Mining Speed</div>
                </div>

                <div>
                  <div className="text-xl font-semibold text-green-400" data-testid={`text-reward-${pkg.id}`}>
                    {parseFloat(pkg.multiplier)} PLC
                  </div>
                  <div className="text-cyan-200">Per Tap</div>
                </div>

                <div>
                  <div className="text-lg font-medium text-white" data-testid={`text-duration-${pkg.id}`}>
                    {formatDuration(pkg.duration)}
                  </div>
                  <div className="text-cyan-200">Duration</div>
                </div>

                <div className="pt-4">
                  <Button
                    className={`w-full ${
                      isCurrentPackage(pkg)
                        ? "bg-green-600 hover:bg-green-700"
                        : "bg-gradient-to-r from-cyan-500 to-green-500 hover:from-cyan-600 hover:to-green-600"
                    } text-white`}
                    disabled={isCurrentPackage(pkg) || upgradeMutation.isPending}
                    onClick={() => upgradeMutation.mutate(pkg.id)}
                    data-testid={`button-upgrade-${pkg.id}`}
                  >
                    {isCurrentPackage(pkg) ? "Currently Active" : "Upgrade"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Benefits Section */}
        <div className="mt-12 text-center">
          <h2 className="text-2xl font-bold mb-6 text-white">Package Benefits</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="glass-card border-cyan-500/20">
              <CardContent className="p-6 text-center">
                <Zap className="h-12 w-12 text-cyan-400 mx-auto mb-4" />
                <h3 className="font-semibold mb-2 text-white">Higher Rewards</h3>
                <p className="text-sm text-cyan-100">
                  Earn more PLC tokens with each mining session based on your package multiplier
                </p>
              </CardContent>
            </Card>

            <Card className="glass-card border-green-500/20">
              <CardContent className="p-6 text-center">
                <Crown className="h-12 w-12 text-green-400 mx-auto mb-4" />
                <h3 className="font-semibold mb-2 text-white">Flexible Duration</h3>
                <p className="text-sm text-green-100">
                  Choose packages with different durations to match your mining strategy
                </p>
              </CardContent>
            </Card>

            <Card className="glass-card border-purple-500/20">
              <CardContent className="p-6 text-center">
                <CheckCircle className="h-12 w-12 text-purple-400 mx-auto mb-4" />
                <h3 className="font-semibold mb-2 text-white">Easy Upgrade</h3>
                <p className="text-sm text-purple-100">
                  Switch between packages anytime to optimize your mining experience
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}