import { Button } from "./button";
import { Pickaxe, Wallet, Users, Zap, Shield } from "lucide-react";
import { Link } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import type { User } from "@shared/schema";

interface BottomNavProps {
  currentPage: string;
}

export default function BottomNav({ currentPage }: BottomNavProps) {
  const { user } = useAuth();

  return (
    <nav className="bg-white border-t border-gray-300 fixed bottom-0 left-0 right-0 z-50">
      <div className="max-w-lg mx-auto px-4">
        <div className="flex justify-around py-3">
          <Link href="/">
            <Button
              variant="ghost"
              className={`flex flex-col items-center space-y-1 h-auto p-2 ${
                currentPage === 'mine' ? 'text-green-600' : 'text-black hover:text-green-600'
              }`}
              data-testid="nav-mine"
            >
              <Pickaxe className="text-lg h-5 w-5" />
              <span className="text-xs">Mine</span>
            </Button>
          </Link>
          
          <Link href="/wallet">
            <Button
              variant="ghost"
              className={`flex flex-col items-center space-y-1 h-auto p-2 ${
                currentPage === 'wallet' ? 'text-green-600' : 'text-black hover:text-green-600'
              }`}
              data-testid="nav-wallet"
            >
              <Wallet className="text-lg h-5 w-5" />
              <span className="text-xs">Wallet</span>
            </Button>
          </Link>
          
          <Link href="/referrals">
            <Button
              variant="ghost"
              className={`flex flex-col items-center space-y-1 h-auto p-2 ${
                currentPage === 'referrals' ? 'text-green-600' : 'text-black hover:text-green-600'
              }`}
              data-testid="nav-referrals"
            >
              <Users className="text-lg h-5 w-5" />
              <span className="text-xs">Referrals</span>
            </Button>
          </Link>
          
          {user?.isAdmin && (
            <Link href="/admin">
              <Button
                variant="ghost"
                className={`flex flex-col items-center space-y-1 h-auto p-2 ${
                  currentPage === 'admin' ? 'text-green-600' : 'text-black hover:text-green-600'
                }`}
                data-testid="nav-admin"
              >
                <Shield className="text-lg h-5 w-5" />
                <span className="text-xs">Admin</span>
              </Button>
            </Link>
          )}
          
          {!user?.isAdmin && (
            <Link href="/mining-packages">
              <Button
                variant="ghost"
                className={`flex flex-col items-center space-y-1 h-auto p-2 ${
                  currentPage === 'mining-packages' ? 'text-green-600' : 'text-black hover:text-green-600'
                }`}
                data-testid="nav-mining-packages"
              >
                <Zap className="text-lg h-5 w-5" />
                <span className="text-xs">Packages</span>
              </Button>
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}
