import { useState, useEffect } from "react";

interface CountdownTimerProps {
  lastMinedAt: string;
}

export default function CountdownTimer({ lastMinedAt }: CountdownTimerProps) {
  const [timeLeft, setTimeLeft] = useState({ hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {
    const calculateTimeLeft = () => {
      const now = new Date().getTime();
      const lastMined = new Date(lastMinedAt).getTime();
      const nextMineTime = lastMined + (24 * 60 * 60 * 1000); // 24 hours later
      const difference = nextMineTime - now;

      if (difference > 0) {
        const hours = Math.floor(difference / (1000 * 60 * 60));
        const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((difference % (1000 * 60)) / 1000);
        
        setTimeLeft({ hours, minutes, seconds });
      } else {
        setTimeLeft({ hours: 0, minutes: 0, seconds: 0 });
      }
    };

    calculateTimeLeft();
    const timer = setInterval(calculateTimeLeft, 1000);

    return () => clearInterval(timer);
  }, [lastMinedAt]);

  return (
    <div className="space-y-2">
      <p className="text-gray-400">Next mine available in:</p>
      <div className="flex justify-center space-x-2">
        <div className="bg-gray-700 rounded-lg px-3 py-2">
          <span className="text-2xl font-mono text-yellow-400" data-testid="countdown-hours">
            {timeLeft.hours.toString().padStart(2, '0')}
          </span>
          <p className="text-xs text-gray-400">Hours</p>
        </div>
        <div className="bg-gray-700 rounded-lg px-3 py-2">
          <span className="text-2xl font-mono text-yellow-400" data-testid="countdown-minutes">
            {timeLeft.minutes.toString().padStart(2, '0')}
          </span>
          <p className="text-xs text-gray-400">Min</p>
        </div>
        <div className="bg-gray-700 rounded-lg px-3 py-2">
          <span className="text-2xl font-mono text-yellow-400" data-testid="countdown-seconds">
            {timeLeft.seconds.toString().padStart(2, '0')}
          </span>
          <p className="text-xs text-gray-400">Sec</p>
        </div>
      </div>
    </div>
  );
}
