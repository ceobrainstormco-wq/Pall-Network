import { Button } from "./button";
import { Pickaxe, Clock } from "lucide-react";

interface MiningButtonProps {
  canMine: boolean;
  onMine: () => void;
  isLoading: boolean;
}

export default function MiningButton({ canMine, onMine, isLoading }: MiningButtonProps) {
  if (isLoading) {
    return (
      <Button 
        disabled 
        className="w-full py-4 px-8 rounded-xl bg-gray-600 cursor-not-allowed text-gray-400 font-semibold text-lg transition-all duration-300 flex items-center justify-center space-x-3"
        data-testid="button-mining-loading"
      >
        <div className="animate-spin w-5 h-5 border-2 border-gray-400 border-t-white rounded-full"></div>
        <span>Mining...</span>
      </Button>
    );
  }

  if (canMine) {
    return (
      <Button 
        onClick={onMine}
        className="w-full py-4 px-8 rounded-xl mining-button-active text-white font-semibold text-lg transition-all duration-300 transform hover:scale-105 active:scale-95 flex items-center justify-center space-x-3"
        data-testid="button-mine"
      >
        <Pickaxe className="h-5 w-5" />
        <span>Mine 1 PLC</span>
      </Button>
    );
  }

  return (
    <Button 
      disabled 
      className="w-full py-4 px-8 rounded-xl mining-button-disabled cursor-not-allowed font-semibold text-lg transition-all duration-300 flex items-center justify-center space-x-3"
      data-testid="button-mining-cooldown"
    >
      <Clock className="h-5 w-5" />
      <span>Mining Cooldown</span>
    </Button>
  );
}
