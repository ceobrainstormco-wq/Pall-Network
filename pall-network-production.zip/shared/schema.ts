import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  integer,
  decimal,
  text,
  boolean,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  username: varchar("username").unique(),
  country: varchar("country"),
  totalMined: decimal("total_mined", { precision: 10, scale: 2 }).default("0"),
  currentBalance: decimal("current_balance", { precision: 10, scale: 2 }).default("0"),
  lastMinedAt: timestamp("last_mined_at"),
  referralCode: varchar("referral_code").unique(),
  referredBy: varchar("referred_by"),
  miningLevel: integer("mining_level").default(1),
  miningStreak: integer("mining_streak").default(0),
  isAdmin: boolean("is_admin").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Mining packages table
export const miningPackages = pgTable("mining_packages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull().unique(),
  multiplier: decimal("multiplier", { precision: 3, scale: 1 }).notNull(),
  duration: integer("duration").notNull(), // Duration in days, 0 for permanent
  description: text("description"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// User mining packages table (tracks user's current package)
export const userMiningPackages = pgTable("user_mining_packages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  packageId: varchar("package_id").notNull().references(() => miningPackages.id),
  activatedAt: timestamp("activated_at").defaultNow(),
  expiresAt: timestamp("expires_at"),
  isActive: boolean("is_active").default(true),
});

// Mining transactions table
export const miningTransactions = pgTable("mining_transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  type: varchar("type").notNull(), // 'mine', 'referral_bonus'
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  multiplier: decimal("multiplier", { precision: 3, scale: 1 }).default("1.0"),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many, one }) => ({
  miningTransactions: many(miningTransactions),
  userMiningPackages: many(userMiningPackages),
  referrer: one(users, {
    fields: [users.referredBy],
    references: [users.referralCode],
  }),
}));

export const miningPackagesRelations = relations(miningPackages, ({ many }) => ({
  userMiningPackages: many(userMiningPackages),
}));

export const userMiningPackagesRelations = relations(userMiningPackages, ({ one }) => ({
  user: one(users, {
    fields: [userMiningPackages.userId],
    references: [users.id],
  }),
  miningPackage: one(miningPackages, {
    fields: [userMiningPackages.packageId],
    references: [miningPackages.id],
  }),
}));

export const miningTransactionsRelations = relations(miningTransactions, ({ one }) => ({
  user: one(users, {
    fields: [miningTransactions.userId],
    references: [users.id],
  }),
}));

// Zod schemas
export const upsertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMiningTransactionSchema = createInsertSchema(miningTransactions).omit({
  id: true,
  createdAt: true,
});

export const insertMiningPackageSchema = createInsertSchema(miningPackages).omit({
  id: true,
  createdAt: true,
});

export const insertUserMiningPackageSchema = createInsertSchema(userMiningPackages).omit({
  id: true,
  activatedAt: true,
});

export const upgradePackageSchema = z.object({
  packageId: z.string().min(1, "Package ID is required"),
});

export const updateUserProfileSchema = z.object({
  username: z.string().min(3).max(20).optional(),
  country: z.string().min(2).max(50).optional(),
});

// Types
export type UpsertUser = z.infer<typeof upsertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertMiningTransaction = z.infer<typeof insertMiningTransactionSchema>;
export type MiningTransaction = typeof miningTransactions.$inferSelect;
export type InsertMiningPackage = z.infer<typeof insertMiningPackageSchema>;
export type MiningPackage = typeof miningPackages.$inferSelect;
export type InsertUserMiningPackage = z.infer<typeof insertUserMiningPackageSchema>;
export type UserMiningPackage = typeof userMiningPackages.$inferSelect;
export type UpgradePackage = z.infer<typeof upgradePackageSchema>;
export type UpdateUserProfile = z.infer<typeof updateUserProfileSchema>;
