import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import type { User, MiningTransaction, MiningPackage, UserMiningPackage } from "@shared/schema";
import TopNav from "@/components/ui/top-nav";
import BottomNav from "@/components/ui/bottom-nav";
import MiningButton from "@/components/ui/mining-button";
import CountdownTimer from "@/components/ui/countdown-timer";
import { Card, CardContent } from "@/components/ui/card";
import { Coins, Wallet, Medal, Users, History, Pickaxe, Copy, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Dashboard() {
  const { user, isLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !user) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [user, isLoading, toast]);

  // Fetch mining status
  const { data: miningStatus, isLoading: statusLoading } = useQuery<{ canMine: boolean }>({
    queryKey: ["/api/mining/can-mine"],
    retry: false,
  });

  // Fetch mining history
  const { data: miningHistory = [], isLoading: historyLoading } = useQuery<MiningTransaction[]>({
    queryKey: ["/api/mining/history"],
    retry: false,
  });

  // Fetch current mining package
  interface CurrentPackageResponse {
    package: MiningPackage;
    userPackage: UserMiningPackage;
  }
  const { data: currentPackage } = useQuery<CurrentPackageResponse | null>({
    queryKey: ["/api/mining/current-package"],
    retry: false,
  });

  // Mining mutation
  const mineMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/mining/mine");
      return response.json();
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/mining/can-mine"] });
      queryClient.invalidateQueries({ queryKey: ["/api/mining/history"] });
      queryClient.invalidateQueries({ queryKey: ["/api/mining/current-package"] });
      toast({
        title: "Mining Successful!",
        description: result.message || "You earned PLC tokens!",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Mining Failed",
        description: error.message || "Please try again.",
        variant: "destructive",
      });
    },
  });

  const copyReferralCode = () => {
    if (user?.referralCode) {
      navigator.clipboard.writeText(user.referralCode);
      toast({
        title: "Copied!",
        description: "Referral code copied to clipboard",
      });
    }
  };

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const past = new Date(timestamp);
    const diffMs = now.getTime() - past.getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffHours / 24);

    if (diffDays > 0) return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
    if (diffHours > 0) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    return 'Just now';
  };

  if (isLoading || !user) {
    return (
      <div className="min-h-screen bg-[hsl(var(--crypto-primary))] flex items-center justify-center">
        <div className="animate-spin w-12 h-12 border-4 border-gray-600 border-t-green-400 rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen crypto-grid-bg text-white pb-20 relative">
      {/* Blockchain Nodes */}
      <div className="blockchain-nodes">
        <div className="blockchain-node" style={{ top: '15%', left: '20%' }}></div>
        <div className="blockchain-node" style={{ top: '35%', right: '25%' }}></div>
        <div className="blockchain-node" style={{ top: '55%', left: '15%' }}></div>
        <div className="blockchain-node" style={{ top: '75%', right: '20%' }}></div>
      </div>
      
      {/* Content Container */}
      <div className="relative z-10">
      <TopNav />
      
      <main className="max-w-lg mx-auto px-4 py-6 space-y-6">
        {/* Welcome Section */}
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-bold text-white" data-testid="text-welcome">
            Welcome, {user.username || user.firstName || 'Miner'}!
          </h2>
          <p className="text-gray-400">Ready to mine some Pall Coins?</p>
        </div>

        {/* Balance Cards */}
        <div className="grid grid-cols-2 gap-4">
          <Card className="crypto-card border-0">
            <CardContent className="p-4 text-center">
              <Coins className="text-green-400 text-2xl mb-2 mx-auto" />
              <p className="text-gray-400 text-sm">Total Mined</p>
              <p className="text-2xl font-bold text-white" data-testid="text-total-mined">
                {user.totalMined || '0'}
              </p>
              <p className="text-green-400 text-xs">PLC</p>
            </CardContent>
          </Card>
          
          <Card className="crypto-card border-0">
            <CardContent className="p-4 text-center">
              <Wallet className="text-yellow-400 text-2xl mb-2 mx-auto" />
              <p className="text-gray-400 text-sm">Current Balance</p>
              <p className="text-2xl font-bold text-white" data-testid="text-current-balance">
                {user.currentBalance || '0'}
              </p>
              <p className="text-green-400 text-xs">PLC</p>
            </CardContent>
          </Card>
        </div>

        {/* Mining Package Section */}
        {currentPackage && (
          <Card className="glass-card border-purple-500/20">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center">
                    <Zap className="text-white text-lg" />
                  </div>
                  <div>
                    <p className="text-white font-semibold" data-testid="text-current-package">
                      {currentPackage.package.name}
                    </p>
                    <p className="text-gray-400 text-sm">Mining Package</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-purple-400 font-semibold" data-testid="text-mining-multiplier">
                    {currentPackage.package.multiplier}x Speed
                  </p>
                  <p className="text-gray-400 text-sm">
                    {currentPackage.package.multiplier} PLC per tap
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Mining Section */}
        <Card className="glass-card border-cyan-500/20">
          <CardContent className="p-6 text-center space-y-4">
            {statusLoading ? (
              <div className="animate-spin w-8 h-8 border-4 border-gray-600 border-t-green-400 rounded-full mx-auto"></div>
            ) : (
              <>
                <MiningButton 
                  canMine={miningStatus?.canMine || false}
                  onMine={() => mineMutation.mutate()}
                  isLoading={mineMutation.isPending}
                />
                
                {!miningStatus?.canMine && user.lastMinedAt && (
                  <CountdownTimer lastMinedAt={user.lastMinedAt.toString()} />
                )}
                
                {miningStatus?.canMine && (
                  <p className="text-gray-400 text-sm">Tap to mine your daily Pall Coin!</p>
                )}
              </>
            )}
          </CardContent>
        </Card>

        {/* Mining Level/Rank */}
        <Card className="glass-card border-purple-500/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 crypto-gradient rounded-full flex items-center justify-center">
                  <Medal className="text-white text-lg" />
                </div>
                <div>
                  <p className="text-white font-semibold" data-testid="text-mining-rank">
                    {user.miningLevel && user.miningLevel >= 10 ? 'Gold Miner' : 
                     user.miningLevel && user.miningLevel >= 5 ? 'Silver Miner' : 'Bronze Miner'}
                  </p>
                  <p className="text-gray-400 text-sm">Level {user.miningLevel || 1}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-green-400 font-semibold" data-testid="text-mining-streak">
                  {user.miningStreak || 0} days
                </p>
                <p className="text-gray-400 text-sm">Mining streak</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Referral Section */}
        <Card className="glass-card border-green-500/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-white font-semibold flex items-center space-x-2">
                  <Users className="text-green-400" />
                  <span>Referral Code</span>
                </h3>
                <p className="text-gray-400 text-sm mt-1">Earn 0.1 PLC per referral</p>
              </div>
              <Button 
                className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors flex items-center space-x-2"
                onClick={copyReferralCode}
                data-testid="button-copy-referral"
              >
                <span className="font-mono">{user.referralCode || 'LOADING'}</span>
                <Copy className="text-sm h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Recent Mining History */}
        <Card className="glass-card border-blue-500/20 overflow-hidden">
          <CardContent className="p-0">
            <div className="p-4 border-b border-gray-700">
              <h3 className="text-white font-semibold flex items-center space-x-2">
                <History className="text-green-400" />
                <span>Recent Mining</span>
              </h3>
            </div>
            
            <div className="divide-y divide-gray-700">
              {historyLoading ? (
                <div className="p-4 text-center">
                  <div className="animate-spin w-6 h-6 border-4 border-gray-600 border-t-green-400 rounded-full mx-auto"></div>
                </div>
              ) : miningHistory.length === 0 ? (
                <div className="p-4 text-center text-gray-400">
                  No mining history yet. Start mining to see your transactions!
                </div>
              ) : (
                miningHistory.slice(0, 5).map((transaction: any) => (
                  <div key={transaction.id} className="p-4 flex items-center justify-between" data-testid={`transaction-${transaction.id}`}>
                    <div className="flex items-center space-x-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        transaction.type === 'mine' ? 'bg-green-600' : 'bg-yellow-600'
                      }`}>
                        {transaction.type === 'mine' ? (
                          <Pickaxe className="text-white text-xs h-4 w-4" />
                        ) : (
                          <Users className="text-white text-xs h-4 w-4" />
                        )}
                      </div>
                      <div>
                        <p className="text-white text-sm">
                          {transaction.type === 'mine' ? 'Mining Reward' : 'Referral Bonus'}
                        </p>
                        <p className="text-gray-400 text-xs">
                          {formatTimeAgo(transaction.createdAt)}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`font-semibold ${
                        transaction.type === 'mine' ? 'text-green-400' : 'text-yellow-400'
                      }`}>
                        +{transaction.amount} PLC
                      </p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </main>

      <BottomNav currentPage="mine" />
      </div>
    </div>
  );
}
