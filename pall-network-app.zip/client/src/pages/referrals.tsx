import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useEffect } from "react";
import type { User, MiningTransaction } from "@shared/schema";
import TopNav from "@/components/ui/top-nav";
import BottomNav from "@/components/ui/bottom-nav";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, Copy, Share2, Trophy, Gift } from "lucide-react";

export default function ReferralsPage() {
  const { user, isLoading } = useAuth();
  const { toast } = useToast();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !user) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [user, isLoading, toast]);

  // Fetch user referrals
  const { data: referrals = [], isLoading: referralsLoading } = useQuery<User[]>({
    queryKey: ["/api/referrals"],
    retry: false,
  });

  // Fetch mining history to count referral bonuses
  const { data: miningHistory = [] } = useQuery<MiningTransaction[]>({
    queryKey: ["/api/mining/history", { limit: 100 }],
    retry: false,
  });

  const referralBonuses = miningHistory.filter((t) => t.type === 'referral_bonus');
  const totalReferralEarnings = referralBonuses.reduce((sum: number, t) => sum + parseFloat(t.amount), 0);

  const copyReferralCode = () => {
    if (user?.referralCode) {
      navigator.clipboard.writeText(user.referralCode);
      toast({
        title: "Copied!",
        description: "Referral code copied to clipboard",
      });
    }
  };

  const shareReferralLink = () => {
    const referralLink = `${window.location.origin}?ref=${user?.referralCode}`;
    if (navigator.share) {
      navigator.share({
        title: 'Join Pall Network',
        text: 'Start mining Pall Coins (PLC) with me! Use my referral code to get started.',
        url: referralLink,
      });
    } else {
      navigator.clipboard.writeText(referralLink);
      toast({
        title: "Link Copied!",
        description: "Referral link copied to clipboard",
      });
    }
  };

  const formatDate = (timestamp: string) => {
    return new Date(timestamp).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  if (isLoading || !user) {
    return (
      <div className="min-h-screen bg-[hsl(var(--crypto-primary))] flex items-center justify-center">
        <div className="animate-spin w-12 h-12 border-4 border-gray-600 border-t-green-400 rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[hsl(var(--crypto-primary))] text-white pb-20">
      <TopNav />
      
      <main className="max-w-lg mx-auto px-4 py-6 space-y-6">
        {/* Referrals Header */}
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-bold text-white flex items-center justify-center space-x-2">
            <Users className="h-6 w-6" />
            <span>Referrals</span>
          </h2>
          <p className="text-gray-400">Invite friends and earn together</p>
        </div>

        {/* Referral Stats */}
        <div className="grid grid-cols-2 gap-4">
          <Card className="crypto-card border-0">
            <CardContent className="p-4 text-center">
              <Users className="text-green-400 text-2xl mb-2 mx-auto" />
              <p className="text-gray-400 text-sm">Total Referrals</p>
              <p className="text-2xl font-bold text-white" data-testid="text-total-referrals">
                {referrals.length}
              </p>
            </CardContent>
          </Card>
          
          <Card className="crypto-card border-0">
            <CardContent className="p-4 text-center">
              <Gift className="text-yellow-400 text-2xl mb-2 mx-auto" />
              <p className="text-gray-400 text-sm">Total Earned</p>
              <p className="text-2xl font-bold text-white" data-testid="text-total-earned">
                {totalReferralEarnings.toFixed(1)}
              </p>
              <p className="text-yellow-400 text-xs">PLC</p>
            </CardContent>
          </Card>
        </div>

        {/* Referral Code Section */}
        <Card className="crypto-card border-0">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Trophy className="h-5 w-5 text-green-400" />
              <span>Your Referral Code</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-gray-800 rounded-lg p-4 text-center">
              <p className="text-gray-400 text-sm mb-2">Your unique referral code</p>
              <p className="text-3xl font-mono font-bold text-green-400" data-testid="text-referral-code">
                {user.referralCode || 'LOADING'}
              </p>
            </div>
            
            <div className="space-y-2">
              <Button 
                onClick={copyReferralCode}
                className="w-full bg-green-600 hover:bg-green-700 text-white flex items-center justify-center space-x-2"
                data-testid="button-copy-code"
              >
                <Copy className="h-4 w-4" />
                <span>Copy Code</span>
              </Button>
              
              <Button 
                onClick={shareReferralLink}
                variant="outline"
                className="w-full border-green-600 text-green-400 hover:bg-green-600 hover:text-white flex items-center justify-center space-x-2"
                data-testid="button-share-link"
              >
                <Share2 className="h-4 w-4" />
                <span>Share Link</span>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* How it Works */}
        <Card className="crypto-card border-0">
          <CardHeader>
            <CardTitle>How Referrals Work</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-green-600 rounded-full flex items-center justify-center text-sm font-bold">1</div>
              <div>
                <p className="text-white font-medium">Share your code</p>
                <p className="text-gray-400 text-sm">Give your referral code to friends</p>
              </div>
            </div>
            
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-green-600 rounded-full flex items-center justify-center text-sm font-bold">2</div>
              <div>
                <p className="text-white font-medium">They join & mine</p>
                <p className="text-gray-400 text-sm">Your friends sign up and start mining</p>
              </div>
            </div>
            
            <div className="flex items-start space-x-3">
              <div className="w-6 h-6 bg-green-600 rounded-full flex items-center justify-center text-sm font-bold">3</div>
              <div>
                <p className="text-white font-medium">You earn bonus</p>
                <p className="text-gray-400 text-sm">Get 0.5 PLC for each successful referral</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Referred Users */}
        <Card className="crypto-card border-0">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Users className="h-5 w-5 text-green-400" />
              <span>Your Referrals</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {referralsLoading ? (
              <div className="p-6 text-center">
                <div className="animate-spin w-8 h-8 border-4 border-gray-600 border-t-green-400 rounded-full mx-auto"></div>
                <p className="text-gray-400 mt-2">Loading referrals...</p>
              </div>
            ) : referrals.length === 0 ? (
              <div className="p-6 text-center text-gray-400">
                <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No referrals yet</p>
                <p className="text-sm">Share your code to start earning referral bonuses!</p>
              </div>
            ) : (
              <div className="divide-y divide-gray-700">
                {referrals.map((referral) => (
                  <div key={referral.id} className="p-4 flex items-center justify-between" data-testid={`referral-${referral.id}`}>
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center">
                        <Users className="text-white h-5 w-5" />
                      </div>
                      <div>
                        <p className="text-white font-medium">
                          {referral.username || referral.firstName || 'Anonymous User'}
                        </p>
                        <p className="text-gray-400 text-sm">
                          Joined {referral.createdAt ? formatDate(referral.createdAt.toString()) : 'Unknown'}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-yellow-400 font-semibold">+0.5 PLC</p>
                      <p className="text-gray-400 text-xs">Bonus Earned</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>

      <BottomNav currentPage="referrals" />
    </div>
  );
}
