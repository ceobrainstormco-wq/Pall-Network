import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useEffect } from "react";
import type { User, MiningTransaction } from "@shared/schema";
import TopNav from "@/components/ui/top-nav";
import BottomNav from "@/components/ui/bottom-nav";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Wallet, ArrowUpDown, History, TrendingUp, Pickaxe, Users } from "lucide-react";

export default function WalletPage() {
  const { user, isLoading } = useAuth();
  const { toast } = useToast();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !user) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [user, isLoading, toast]);

  // Fetch complete mining history
  const { data: miningHistory = [], isLoading: historyLoading } = useQuery<MiningTransaction[]>({
    queryKey: ["/api/mining/history", { limit: 50 }],
    retry: false,
  });

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const past = new Date(timestamp);
    const diffMs = now.getTime() - past.getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffHours / 24);

    if (diffDays > 0) return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
    if (diffHours > 0) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    return 'Just now';
  };

  const formatDate = (timestamp: string) => {
    return new Date(timestamp).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (isLoading || !user) {
    return (
      <div className="min-h-screen bg-[hsl(var(--crypto-primary))] flex items-center justify-center">
        <div className="animate-spin w-12 h-12 border-4 border-gray-600 border-t-green-400 rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[hsl(var(--crypto-primary))] text-white pb-20">
      <TopNav />
      
      <main className="max-w-lg mx-auto px-4 py-6 space-y-6">
        {/* Wallet Header */}
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-bold text-white flex items-center justify-center space-x-2">
            <Wallet className="h-6 w-6" />
            <span>My Wallet</span>
          </h2>
          <p className="text-gray-400">Manage your Pall Coin balance</p>
        </div>

        {/* Balance Overview */}
        <Card className="crypto-card border-0">
          <CardContent className="p-6 text-center space-y-4">
            <div className="space-y-2">
              <p className="text-gray-400 text-sm">Current Balance</p>
              <p className="text-4xl font-bold text-white" data-testid="text-wallet-balance">
                {user.currentBalance || '0'}
              </p>
              <p className="text-green-400 text-lg font-semibold">PLC</p>
            </div>
            
            <div className="grid grid-cols-2 gap-4 pt-4 border-t border-gray-700">
              <div className="text-center">
                <p className="text-2xl font-bold text-green-400">{user.totalMined || '0'}</p>
                <p className="text-gray-400 text-sm">Total Mined</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-yellow-400">{miningHistory.filter((t) => t.type === 'referral_bonus').length}</p>
                <p className="text-gray-400 text-sm">Referral Rewards</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-4">
          <Button 
            variant="outline" 
            className="h-auto p-4 flex flex-col space-y-2 crypto-card border-gray-600 hover:bg-gray-700 disabled:opacity-50"
            disabled
            data-testid="button-withdraw"
          >
            <ArrowUpDown className="h-6 w-6" />
            <span className="text-sm">Withdraw</span>
            <span className="text-xs text-gray-400">Coming Soon</span>
          </Button>
          
          <Button 
            variant="outline" 
            className="h-auto p-4 flex flex-col space-y-2 crypto-card border-gray-600 hover:bg-gray-700"
            data-testid="button-analytics"
          >
            <TrendingUp className="h-6 w-6" />
            <span className="text-sm">Analytics</span>
            <span className="text-xs text-gray-400">View Stats</span>
          </Button>
        </div>

        {/* Transaction History */}
        <Card className="crypto-card border-0">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <History className="h-5 w-5 text-green-400" />
              <span>Transaction History</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {historyLoading ? (
              <div className="p-6 text-center">
                <div className="animate-spin w-8 h-8 border-4 border-gray-600 border-t-green-400 rounded-full mx-auto"></div>
                <p className="text-gray-400 mt-2">Loading transactions...</p>
              </div>
            ) : miningHistory.length === 0 ? (
              <div className="p-6 text-center text-gray-400">
                <History className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No transactions yet</p>
                <p className="text-sm">Start mining to see your transaction history!</p>
              </div>
            ) : (
              <div className="divide-y divide-gray-700 max-h-96 overflow-y-auto">
                {miningHistory.map((transaction) => (
                  <div key={transaction.id} className="p-4 hover:bg-gray-800 transition-colors" data-testid={`wallet-transaction-${transaction.id}`}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          transaction.type === 'mine' ? 'bg-green-600' : 'bg-yellow-600'
                        }`}>
                          {transaction.type === 'mine' ? (
                            <Pickaxe className="text-white h-5 w-5" />
                          ) : (
                            <Users className="text-white h-5 w-5" />
                          )}
                        </div>
                        <div>
                          <p className="text-white font-medium">
                            {transaction.type === 'mine' ? 'Daily Mining' : 'Referral Bonus'}
                          </p>
                          <p className="text-gray-400 text-sm">
                            {transaction.description || 'Mining reward'}
                          </p>
                          <p className="text-gray-500 text-xs">
                            {transaction.createdAt ? formatDate(transaction.createdAt.toString()) : 'Unknown'}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className={`font-bold text-lg ${
                          transaction.type === 'mine' ? 'text-green-400' : 'text-yellow-400'
                        }`}>
                          +{transaction.amount}
                        </p>
                        <p className="text-gray-400 text-xs">PLC</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Wallet Info */}
        <Card className="crypto-card border-0">
          <CardContent className="p-4">
            <div className="space-y-3">
              <h3 className="font-semibold text-white">Wallet Information</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-400">Wallet Address:</span>
                  <span className="text-white font-mono">{user.id?.slice(0, 12)}...{user.id?.slice(-6)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Account Created:</span>
                  <span className="text-white">{user.createdAt ? formatDate(user.createdAt.toString()) : 'Unknown'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Mining Level:</span>
                  <span className="text-green-400 font-semibold">Level {user.miningLevel || 1}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>

      <BottomNav currentPage="wallet" />
    </div>
  );
}
