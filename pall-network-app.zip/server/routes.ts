import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { z } from "zod";
import { updateUserProfileSchema, upgradePackageSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Profile routes
  app.patch('/api/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const profileData = updateUserProfileSchema.parse(req.body);
      const user = await storage.updateUserProfile(userId, profileData);
      res.json(user);
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(400).json({ message: "Failed to update profile" });
    }
  });

  // Mining routes
  app.get('/api/mining/can-mine', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const canMine = await storage.canUserMine(userId);
      res.json({ canMine });
    } catch (error) {
      console.error("Error checking mining status:", error);
      res.status(500).json({ message: "Failed to check mining status" });
    }
  });

  app.post('/api/mining/mine', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const result = await storage.mineCoins(userId);
      
      if (result.success) {
        res.json(result);
      } else {
        res.status(400).json(result);
      }
    } catch (error) {
      console.error("Error mining coins:", error);
      res.status(500).json({ message: "Mining failed" });
    }
  });

  app.get('/api/mining/history', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const limit = parseInt(req.query.limit as string) || 10;
      const history = await storage.getUserMiningHistory(userId, limit);
      res.json(history);
    } catch (error) {
      console.error("Error fetching mining history:", error);
      res.status(500).json({ message: "Failed to fetch mining history" });
    }
  });

  // Referral routes
  app.get('/api/referrals', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const referrals = await storage.getUserReferrals(userId);
      res.json(referrals);
    } catch (error) {
      console.error("Error fetching referrals:", error);
      res.status(500).json({ message: "Failed to fetch referrals" });
    }
  });

  // Mining package routes
  app.get('/api/mining/packages', isAuthenticated, async (req: any, res) => {
    try {
      const packages = await storage.getAllMiningPackages();
      res.json(packages);
    } catch (error) {
      console.error("Error fetching mining packages:", error);
      res.status(500).json({ message: "Failed to fetch mining packages" });
    }
  });

  app.get('/api/mining/current-package', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const activePackage = await storage.getUserActivePackage(userId);
      res.json(activePackage);
    } catch (error) {
      console.error("Error fetching user package:", error);
      res.status(500).json({ message: "Failed to fetch current package" });
    }
  });

  app.post('/api/mining/upgrade-package', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const packageData = upgradePackageSchema.parse(req.body);
      const result = await storage.upgradeUserPackage(userId, packageData);
      
      if (result.success) {
        res.json(result);
      } else {
        res.status(400).json(result);
      }
    } catch (error) {
      console.error("Error upgrading package:", error);
      res.status(500).json({ message: "Package upgrade failed" });
    }
  });

  // Admin routes
  app.get('/api/admin/users', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.get('/api/admin/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const stats = await storage.getMiningStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  app.post('/api/admin/reset-timer/:userId', isAuthenticated, async (req: any, res) => {
    try {
      const adminUserId = req.user.claims.sub;
      const targetUserId = req.params.userId;
      const adminUser = await storage.getUser(adminUserId);
      
      if (!adminUser?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const user = await storage.resetUserMiningTimer(targetUserId);
      res.json(user);
    } catch (error) {
      console.error("Error resetting timer:", error);
      res.status(500).json({ message: "Failed to reset timer" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
