import {
  users,
  miningTransactions,
  miningPackages,
  userMiningPackages,
  type User,
  type UpsertUser,
  type InsertMiningTransaction,
  type MiningTransaction,
  type MiningPackage,
  type UserMiningPackage,
  type InsertMiningPackage,
  type InsertUserMiningPackage,
  type UpgradePackage,
  type UpdateUserProfile,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql, and, gte } from "drizzle-orm";
import { randomBytes } from "crypto";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Profile operations
  updateUserProfile(userId: string, profile: UpdateUserProfile): Promise<User>;
  
  // Mining operations
  canUserMine(userId: string): Promise<boolean>;
  mineCoins(userId: string): Promise<{ success: boolean; transaction?: MiningTransaction; message: string }>;
  getUserMiningHistory(userId: string, limit?: number): Promise<MiningTransaction[]>;
  
  // Mining package operations
  getAllMiningPackages(): Promise<MiningPackage[]>;
  getUserActivePackage(userId: string): Promise<{ package: MiningPackage; userPackage: UserMiningPackage } | null>;
  upgradeUserPackage(userId: string, packageData: UpgradePackage): Promise<{ success: boolean; message: string; userPackage?: UserMiningPackage }>;
  getUserCurrentMultiplier(userId: string): Promise<number>;
  
  // Referral operations
  generateReferralCode(): string;
  processReferralBonus(referrerCode: string, newUserId: string): Promise<void>;
  getUserReferrals(userId: string): Promise<User[]>;
  
  // Admin operations
  getAllUsers(): Promise<User[]>;
  getMiningStats(): Promise<{
    totalUsers: number;
    totalMinedCoins: string;
    dailyActiveMiners: number;
    topMiners: Array<{ user: User; totalMined: string }>;
  }>;
  resetUserMiningTimer(userId: string): Promise<User>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    // Generate referral code if not provided
    if (!userData.referralCode) {
      userData.referralCode = this.generateReferralCode();
    }
    
    // Check if user already exists
    const existingUser = await this.getUser(userData.email || '');
    const isNewUser = !existingUser;
    
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.email,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    
    // Assign default "Free Basic" package to new users
    if (isNewUser) {
      const [freePackage] = await db
        .select()
        .from(miningPackages)
        .where(eq(miningPackages.name, 'Free Basic'));
      
      if (freePackage) {
        await db
          .insert(userMiningPackages)
          .values({
            userId: user.id,
            packageId: freePackage.id,
            expiresAt: null, // Free Basic is permanent
            isActive: true,
          });
      }
    }
    
    // Process referral bonus if referred by someone
    if (userData.referredBy) {
      await this.processReferralBonus(userData.referredBy, user.id);
    }
    
    return user;
  }

  async updateUserProfile(userId: string, profile: UpdateUserProfile): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ ...profile, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Mining operations
  async canUserMine(userId: string): Promise<boolean> {
    const user = await this.getUser(userId);
    if (!user || !user.lastMinedAt) return true;
    
    const now = new Date();
    const lastMined = new Date(user.lastMinedAt);
    const timeDiff = now.getTime() - lastMined.getTime();
    const twentyFourHours = 24 * 60 * 60 * 1000;
    
    return timeDiff >= twentyFourHours;
  }

  async mineCoins(userId: string): Promise<{ success: boolean; transaction?: MiningTransaction; message: string }> {
    const canMine = await this.canUserMine(userId);
    if (!canMine) {
      return { success: false, message: "Mining cooldown active. Please wait 24 hours between mining sessions." };
    }

    // Get user's current mining multiplier
    const multiplier = await this.getUserCurrentMultiplier(userId);
    const baseMiningAmount = 1.0;
    const miningAmount = (baseMiningAmount * multiplier).toFixed(2);
    const now = new Date();

    try {
      // Start transaction
      const result = await db.transaction(async (tx) => {
        // Update user balance and last mined timestamp
        const [updatedUser] = await tx
          .update(users)
          .set({
            totalMined: sql`${users.totalMined} + ${miningAmount}`,
            currentBalance: sql`${users.currentBalance} + ${miningAmount}`,
            lastMinedAt: now,
            miningStreak: sql`${users.miningStreak} + 1`,
            updatedAt: now,
          })
          .where(eq(users.id, userId))
          .returning();

        // Create mining transaction record
        const [transaction] = await tx
          .insert(miningTransactions)
          .values({
            userId,
            type: 'mine',
            amount: miningAmount,
            multiplier: multiplier.toString(),
            description: `Daily mining reward (${multiplier}x multiplier)`,
          })
          .returning();

        return { updatedUser, transaction };
      });

      return {
        success: true,
        transaction: result.transaction,
        message: `Successfully mined ${miningAmount} PLC! (${multiplier}x multiplier)`,
      };
    } catch (error) {
      console.error("Mining error:", error);
      return { success: false, message: "Mining failed. Please try again." };
    }
  }

  async getUserMiningHistory(userId: string, limit: number = 10): Promise<MiningTransaction[]> {
    return await db
      .select()
      .from(miningTransactions)
      .where(eq(miningTransactions.userId, userId))
      .orderBy(desc(miningTransactions.createdAt))
      .limit(limit);
  }

  // Referral operations
  generateReferralCode(): string {
    return randomBytes(3).toString('hex').toUpperCase();
  }

  async processReferralBonus(referrerCode: string, newUserId: string): Promise<void> {
    const [referrer] = await db
      .select()
      .from(users)
      .where(eq(users.referralCode, referrerCode));

    if (!referrer) return;

    const bonusAmount = "0.1";

    try {
      await db.transaction(async (tx) => {
        // Update referrer balance
        await tx
          .update(users)
          .set({
            currentBalance: sql`${users.currentBalance} + ${bonusAmount}`,
            updatedAt: new Date(),
          })
          .where(eq(users.id, referrer.id));

        // Create referral bonus transaction
        await tx
          .insert(miningTransactions)
          .values({
            userId: referrer.id,
            type: 'referral_bonus',
            amount: bonusAmount,
            description: 'Referral bonus reward',
          });
      });
    } catch (error) {
      console.error("Referral bonus error:", error);
    }
  }

  async getUserReferrals(userId: string): Promise<User[]> {
    const user = await this.getUser(userId);
    if (!user?.referralCode) return [];

    return await db
      .select()
      .from(users)
      .where(eq(users.referredBy, user.referralCode));
  }

  // Admin operations
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(desc(users.createdAt));
  }

  async getMiningStats(): Promise<{
    totalUsers: number;
    totalMinedCoins: string;
    dailyActiveMiners: number;
    topMiners: Array<{ user: User; totalMined: string }>;
  }> {
    const totalUsers = await db
      .select({ count: sql<number>`count(*)` })
      .from(users);

    const totalMinedResult = await db
      .select({ total: sql<string>`COALESCE(SUM(${users.totalMined}), 0)` })
      .from(users);

    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);

    const dailyActiveMiners = await db
      .select({ count: sql<number>`count(*)` })
      .from(users)
      .where(gte(users.lastMinedAt, yesterday));

    const topMiners = await db
      .select()
      .from(users)
      .orderBy(desc(users.totalMined))
      .limit(10);

    return {
      totalUsers: totalUsers[0]?.count || 0,
      totalMinedCoins: totalMinedResult[0]?.total || "0",
      dailyActiveMiners: dailyActiveMiners[0]?.count || 0,
      topMiners: topMiners.map(user => ({ user, totalMined: user.totalMined || "0" })),
    };
  }

  async resetUserMiningTimer(userId: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        lastMinedAt: null,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Mining package operations
  async getAllMiningPackages(): Promise<MiningPackage[]> {
    return await db
      .select()
      .from(miningPackages)
      .where(eq(miningPackages.isActive, true))
      .orderBy(miningPackages.multiplier);
  }

  async getUserActivePackage(userId: string): Promise<{ package: MiningPackage; userPackage: UserMiningPackage } | null> {
    const result = await db
      .select({
        package: miningPackages,
        userPackage: userMiningPackages,
      })
      .from(userMiningPackages)
      .innerJoin(miningPackages, eq(userMiningPackages.packageId, miningPackages.id))
      .where(
        and(
          eq(userMiningPackages.userId, userId),
          eq(userMiningPackages.isActive, true),
          sql`(${userMiningPackages.expiresAt} IS NULL OR ${userMiningPackages.expiresAt} > NOW())`
        )
      )
      .orderBy(desc(userMiningPackages.activatedAt))
      .limit(1);

    return result[0] || null;
  }

  async upgradeUserPackage(userId: string, packageData: UpgradePackage): Promise<{ success: boolean; message: string; userPackage?: UserMiningPackage }> {
    try {
      // Get the package details
      const [targetPackage] = await db
        .select()
        .from(miningPackages)
        .where(and(eq(miningPackages.id, packageData.packageId), eq(miningPackages.isActive, true)));

      if (!targetPackage) {
        return { success: false, message: "Invalid mining package selected." };
      }

      // Check if user already has an active package
      const currentPackage = await this.getUserActivePackage(userId);
      
      const now = new Date();
      let expiresAt: Date | null = null;
      
      if (targetPackage.duration > 0) {
        expiresAt = new Date(now.getTime() + (targetPackage.duration * 24 * 60 * 60 * 1000));
      }

      const result = await db.transaction(async (tx) => {
        // Deactivate current package if exists
        if (currentPackage) {
          await tx
            .update(userMiningPackages)
            .set({ isActive: false })
            .where(eq(userMiningPackages.id, currentPackage.userPackage.id));
        }

        // Create new active package
        const [userPackage] = await tx
          .insert(userMiningPackages)
          .values({
            userId,
            packageId: packageData.packageId,
            expiresAt,
            isActive: true,
          })
          .returning();

        return userPackage;
      });

      return {
        success: true,
        message: `Successfully upgraded to ${targetPackage.name}! Mining multiplier is now ${targetPackage.multiplier}x.`,
        userPackage: result,
      };
    } catch (error) {
      console.error("Package upgrade error:", error);
      return { success: false, message: "Failed to upgrade package. Please try again." };
    }
  }

  async getUserCurrentMultiplier(userId: string): Promise<number> {
    const activePackage = await this.getUserActivePackage(userId);
    return activePackage ? parseFloat(activePackage.package.multiplier) : 1.0;
  }
}

export const storage = new DatabaseStorage();
